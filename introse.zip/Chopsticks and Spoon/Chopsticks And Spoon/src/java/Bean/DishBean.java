/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Bean;

/**
 *
 * @author Keiko Nagano
 */
public class DishBean {
    private int dishID;
    private String dishName;

    public int getDishID() {
        return dishID;
    }

    public String getDishName() {
        return dishName;
    }

    public void setDishID(int dishID) {
        this.dishID = dishID;
    }

    public void setDishName(String dishName) {
        this.dishName = dishName;
    }
    
    
}
